*PADS-LIBRARY-PART-TYPES-V9*

TCJB226M025R0150E CAPPM3528X210N I CAP 7 1 0 0 0
TIMESTAMP 2026.05.08.22.24.31
"Mouser Part Number" 581-CJB226M025R0150E
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/KYOCERA-AVX/TCJB226M025R0150E?qs=P1JMDcb91o5Hhw0hk0XD0w%3D%3D
"Manufacturer_Name" Kyocera AVX
"Manufacturer_Part_Number" TCJB226M025R0150E
"Description" Capacitor Polymer 25V 22uF 20% 1210
"Datasheet Link" http://datasheets.avx.com/TCJ.pdf
"Geometry.Height" 2.1mm
GATE 1 2 0
TCJB226M025R0150E
1 0 U +
2 0 U -

*END*
*REMARK* SamacSys ECAD Model
19939569/2054423/2.50/2/5/Capacitor Polarised
